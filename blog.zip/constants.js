const baseUrl = {
    client: "http://localhost:3000",
    server: "http://localhost:3080"
};

const maxNumOfClapsPerUserPerPost = 5;

module.exports = { baseUrl, maxNumOfClapsPerUserPerPost };