// Important! - This is just a naive implementation for example. You can modify all of the implementation in this file.

const Tags = {
    "Server": {
        "11":true
    },
    "Frontend": {}
};

module.exports = { Tags };