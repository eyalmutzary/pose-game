// Important! - This is just a naive implementation for example. You can modify all of the implementation in this file.

const Posts = [
    {id: "11", title: 'Example Title 1', content: 'Example content 1', userId: "11"},
    {id: "12", title: 'Example Title 2', content: 'Example content 2', userId: "11"},
    {id: "13", title: 'Example Title 3', content: 'Example Title that has more then 100 characters... Example Title that has more then 300 characters... Example Title that has more then 300 characters... Example Title that has more then 300 characters... Example Title that has more then 300 characters... Example Title that has more then 300 characters...', userId: "11"}
];

module.exports = { Posts };